# Change Log

## [1.0.0] 2025-07-18

### Initial Release
